﻿using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace ParameterAwareMutexOperationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string instance = Name + " " + String.Join(" ", args);

            Console.WriteLine("Instance: " + instance);

            // do check arguments here. application can exit for invalid requests before getting mutex.

            var mutex = new Mutex(false, instance);

            Console.Write("Waiting...");

            try
            {
                mutex.WaitOne();

                RunProcess();  // do critical work here
            }
            finally
            {
                mutex.ReleaseMutex();
                mutex.Dispose();
            }

            Console.WriteLine("Closing...");
            Thread.Sleep(2000);  // do some less critical work here
        }

        static void RunProcess()
        {
            Console.SetCursorPosition(0, Console.CursorTop);
            Console.WriteLine("Processing...");
            Thread.Sleep(7000);
        }

        static string Name
        {
            get
            {
                return AppDomain.CurrentDomain.FriendlyName;
            }
        }
    }
}
